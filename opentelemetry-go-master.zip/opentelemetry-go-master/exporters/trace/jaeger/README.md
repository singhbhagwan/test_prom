# OpenTelemetry-Go Jaeger Exporter

OpenTelemetry Jaeger exporter 

## Installation
```
go get -u go.opentelemetry.io/otel/exporters/trace/jaeger
```
