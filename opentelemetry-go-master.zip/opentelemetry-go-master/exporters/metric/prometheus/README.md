# OpenTelemetry-Go Prometheus Exporter

OpenTelemetry Prometheus exporter 

## Installation
```
go get -u go.opentelemetry.io/otel/exporters/metric/prometheus
```
